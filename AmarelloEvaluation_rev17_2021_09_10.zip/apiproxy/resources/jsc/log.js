print("request: " + context.getVariable("request.content"));
print("response: " + context.getVariable("response.content"));